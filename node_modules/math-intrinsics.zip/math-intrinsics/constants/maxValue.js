'use strict';

/** @type {import('./maxValue')}  */
// eslint-disable-next-line no-extra-parens
module.exports = /** @type {import('./maxValue')}  */ (Number.MAX_VALUE) || 1.7976931348623157e+308;
